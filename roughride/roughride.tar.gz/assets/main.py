#!/usr/bin/env python3
"""Rough Ride: bicycle obstacle course game. Pygame port (keyboard + touch) of the
original Tkinter desktop game, for the browser. Physics/course data are unchanged
from the original; only rendering, input and the game loop were rewritten.
"""
import os
os.environ.setdefault('SDL_VIDEO_CENTERED', '1')
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
import asyncio
import math
import random
import time
import json
import tempfile
from pathlib import Path
import pygame as pg

W, H = 1120, 700
DT = 1 / 120


class Point:
    def __init__(self, x, y, radius=8):
        self.x, self.y = x, y
        self.ox, self.oy = x, y
        self.radius = radius
        self.ground = False

    def move(self):
        vx, vy = (self.x-self.ox)*.999, (self.y-self.oy)*.999
        self.ox, self.oy = self.x, self.y
        self.x += vx
        self.y += vy + 1100*DT*DT


def distance(a, b):
    return math.hypot(a.x-b.x, a.y-b.y)


def constrain(a, b, length):
    d = distance(a, b)
    if d < .001:
        return
    f = (d-length)/d*.5
    dx, dy = (b.x-a.x)*f, (b.y-a.y)*f
    a.x += dx
    a.y += dy
    b.x -= dx
    b.y -= dy


COURSES = [
    dict(name='THE FIRST BAD IDEA', subtitle='Find your balance. Then leave the ground.',
         terrain=[(0,540),(650,540),(920,460),(1120,460),(1350,540),(1730,540),(1980,435),(2150,435),None,(2300,530),(2830,530),(3040,470),(3350,470),(3650,540),(4230,540)],
         spikes=[(1450,1550,540),(2690,2770,530)], saws=[], checkpoints=[(1190,492),(2480,530)], finish=4020),
    dict(name='INDUSTRIAL ACCIDENT', subtitle='Mind the gap. And the spinning machinery.',
         terrain=[(0,540),(620,540),(900,430),(1120,430),None,(1320,520),(1690,520),(1910,450),(2150,450),None,(2360,500),(2790,500),(3020,410),(3210,410),None,(3310,470),(4110,530),(4470,530)],
         spikes=[(1480,1570,520),(2600,2720,500),(3850,3970,530)], saws=[(2040,235,29,65),(3600,325,32,160)], checkpoints=[(1370,520),(3460,530)], finish=4300),
    dict(name='QUESTIONABLE ENGINEERING', subtitle='Three gaps. Two saws. One very bad commute.',
         terrain=[(0,540),(510,540),(780,400),(960,400),None,(1110,480),(1510,500),(1740,370),(1930,370),None,(2090,460),(2520,490),(2790,390),(2980,390),None,(3130,480),(3590,510),(3830,430),(4100,430),(4400,540),(4800,540)],
         spikes=[(1350,1440,500),(2330,2430,490),(3420,3500,510)], saws=[(2630,230,30,70),(4020,215,35,45)], checkpoints=[(1230,500),(3260,510)], finish=4650)
]


class World:
    def __init__(self, level=0):
        self.level = level
        self.course = COURSES[level]
        self.segments = []
        prev = None
        for p in self.course['terrain']:
            if p is not None and prev is not None:
                self.segments.append((*prev,*p))
            prev = p
        self.checkpoint = -1
        self.deaths = 0
        self.elapsed = 0
        self.spawn()

    def spawn(self, jump_held=False):
        x,y = (160,540) if self.checkpoint < 0 else self.course['checkpoints'][self.checkpoint]
        # Align the whole wheelbase with the checkpoint's actual surface.
        tx,ty = 1.0,0.0
        for x1,y1,x2,y2 in self.segments:
            if x1 <= x <= x2:
                # Some flags are close to a gap: keep both wheels on this segment.
                if x2-x1 >= 100:
                    x = max(x1+45,min(x,x2-45))
                length = math.hypot(x2-x1,y2-y1)
                tx,ty = (x2-x1)/length,(y2-y1)/length
                y = y1+(x-x1)*(y2-y1)/(x2-x1)
                break
        cx,cy = x+ty*22.5,y-tx*22.5
        self.back = Point(cx-38*tx,cy-38*ty,22)
        self.front = Point(cx+38*tx,cy+38*ty,22)
        self.dead = self.won = False
        self.ragdoll = []
        self.links = []
        self.jump_ready = not jump_held
        self.airtime = 0
        self.jumps_used = 0
        self.jump_age = 1.0
        self.suspension = 0.0
        self.spring_velocity = 0.0
        self.lean = 0.0
        self.pedal = 0.0
        self.effects = []

    def local(self, x, y):
        a,b = self.back,self.front
        theta = math.atan2(b.y-a.y,b.x-a.x)
        return ((a.x+b.x)/2+x*math.cos(theta)-y*math.sin(theta),
                (a.y+b.y)/2+x*math.sin(theta)+y*math.cos(theta))

    def rider(self):
        bounce = self.suspension
        foot_x, foot_y = math.cos(self.pedal)*11, -5+math.sin(self.pedal)*11
        return [self.local(-10,-45+bounce),self.local(-3+self.lean,-79+bounce),self.local(4+self.lean,-101+bounce),
                self.local(24+self.lean*.4,-59+bounce*.5),self.local(38,-37),
                self.local(17+foot_x*.35,-24+foot_y*.3),self.local(foot_x,foot_y)]

    def puff(self, x, y, color):
        for _ in range(9):
            self.effects.append([x,y,random.uniform(-65,65),random.uniform(-80,-15),.4,color])
        self.effects = self.effects[-60:]

    def collide(self,p):
        for x1,y1,x2,y2 in self.segments:
            if p.x < x1-p.radius or p.x > x2+p.radius:
                continue
            dx,dy = x2-x1,y2-y1
            t = max(0,min(1,((p.x-x1)*dx+(p.y-y1)*dy)/(dx*dx+dy*dy)))
            qx,qy = x1+t*dx,y1+t*dy
            nx,ny = p.x-qx,p.y-qy
            d = math.hypot(nx,ny)
            if d < p.radius and d > .0001:
                nx,ny = nx/d,ny/d
                p.x += nx*(p.radius-d)
                p.y += ny*(p.radius-d)
                vx,vy = p.x-p.ox,p.y-p.oy
                vn = min(0,vx*nx+vy*ny)
                p.ox = p.x-(vx-vn*nx)*.995
                p.oy = p.y-(vy-vn*ny)*.995
                if ny < -.3:
                    p.ground = True

    def crash(self):
        if self.dead or self.won:
            return
        self.dead = True
        self.deaths += 1
        self.puff(self.front.x,self.front.y,'#d8b482')
        vx,vy = self.front.x-self.front.ox,self.front.y-self.front.oy
        self.ragdoll = [Point(x,y,12 if i==2 else 7) for i,(x,y) in enumerate(self.rider())]
        for p in self.ragdoll:
            p.ox = p.x-vx-random.uniform(-1,1)
            p.oy = p.y-vy+random.uniform(0,2)
        self.links = [(a,b,distance(self.ragdoll[a],self.ragdoll[b])) for a,b in [(0,1),(1,2),(1,3),(3,4),(0,5),(5,6)]]

    def step(self,keys):
        if self.won:
            return
        self.elapsed += DT
        a,b = self.back,self.front
        grounded = a.ground or b.ground
        self.jump_age += DT
        self.airtime = 0 if grounded else self.airtime+DT
        if grounded and self.jump_age > .14:
            self.jumps_used = 0
        elif self.airtime > .12 and self.jumps_used == 0:
            self.jumps_used = 1  # Riding off an edge still leaves an air jump.
        for fx in self.effects:
            fx[0] += fx[2]*DT
            fx[1] += fx[3]*DT
            fx[3] += 160*DT
            fx[4] -= DT
        self.effects = [fx for fx in self.effects if fx[4]>0]
        self.spring_velocity += (-95*self.suspension-15*self.spring_velocity)*DT
        self.suspension = max(-4,min(9,self.suspension+self.spring_velocity*DT))
        if not self.dead:
            if 'Up' in keys:
                for p in (a,b):
                    if p.ground:
                        p.x += 720*DT*DT
            if 'Down' in keys:
                for p in (a,b):
                    p.ox = p.x-(p.x-p.ox)*.96
            tilt = ('Right' in keys)-('Left' in keys)
            self.lean += (tilt*10-self.lean)*.045
            if 'Up' in keys:
                self.pedal += max(.035,abs(a.x-a.ox)*.045)
            dx,dy = b.x-a.x,b.y-a.y
            a.x += dy*tilt*.0009
            a.y -= dx*tilt*.0009
            b.x -= dy*tilt*.0009
            b.y += dx*tilt*.0009
            if 'space' not in keys:
                self.jump_ready = True
            if 'space' in keys and self.jump_ready:
                self.jump_ready = False
                if self.jumps_used < 2:
                    jump_speed = 510 if self.jumps_used == 0 else 480
                    # Equal impulse preserves the bike's tilt and forward speed.
                    average_vy = ((a.y-a.oy)+(b.y-b.oy))*.5
                    impulse = -jump_speed*DT-average_vy
                    for p in (a,b):
                        p.oy -= impulse
                    self.jumps_used += 1
                    self.jump_age = 0
                    self.spring_velocity = -35
                    self.puff((a.x+b.x)/2,(a.y+b.y)/2+20,'#edbd61')
            if 'z' in keys or 'Z' in keys:
                self.crash()
            for p in (a,b):
                vx = max(-5,min(5,p.x-p.ox))
                p.ox = p.x-vx
        incoming_vy = ((a.y-a.oy)+(b.y-b.oy))*.5/DT
        for p in [a,b]+self.ragdoll:
            p.ground = False
            p.move()
        for _ in range(7):
            constrain(a,b,76)
            self.collide(a)
            self.collide(b)
            for i,j,l in self.links:
                constrain(self.ragdoll[i],self.ragdoll[j],l)
            for p in self.ragdoll:
                self.collide(p)
        if not grounded and (a.ground or b.ground) and incoming_vy>90:
            self.spring_velocity = min(100,incoming_vy*.18)
            self.puff((a.x+b.x)/2,(a.y+b.y)/2+20,'#bac3aa')
        if self.dead:
            return
        checks = [(a.x,a.y,19),(b.x,b.y,19)]+[(x,y,10) for x,y in self.rider()[:3]]
        for x,y,r in checks:
            for lo,hi,top in self.course['spikes']:
                if lo-r*.5 < x < hi+r*.5 and top-30-r < y < top+35:
                    self.crash()
            for sx,sy,sr,travel in self.course['saws']:
                sy += math.sin(self.elapsed*1.8)*travel
                if math.hypot(x-sx,y-sy) < sr+r:
                    self.crash()
        for x,y in self.rider()[1:3]:
            for x1,y1,x2,y2 in self.segments:
                if x1 <= x <= x2 and y+9 > y1+(y2-y1)*(x-x1)/(x2-x1):
                    self.crash()
        if max(a.y,b.y) > 880:
            self.crash()
        if not self.dead:
            for i,(x,y) in enumerate(self.course['checkpoints']):
                if a.x > x and i > self.checkpoint:
                    self.checkpoint = i
            if a.x > self.course['finish']:
                self.won = True


class App:
    def __init__(self, fullscreen=False):
        pg.display.init()
        pg.font.init()
        self.screen = pg.display.set_mode((W, H), pg.FULLSCREEN if fullscreen else 0)
        pg.display.set_caption('Rough Ride')
        self.fonts = {}
        self.keys = set()
        self.contacts = {}
        self.mode = 'menu'
        self.world = World()
        self.camera = 0
        self.saved = False
        self.running = True
        self.scorefile = Path(__file__).resolve().with_name('records.json')
        try:
            self.records = json.loads(self.scorefile.read_text())
        except (OSError, ValueError):
            self.records = {}
        self.previous = time.perf_counter()
        self.accumulator = 0

        # On-screen touch controls: same key tokens World.step() already expects.
        self.btn_pedal = pg.Rect(30, 500, 160, 70)
        self.btn_left = pg.Rect(210, 500, 100, 70)
        self.btn_right = pg.Rect(320, 500, 100, 70)
        self.btn_brake = pg.Rect(W-260, 500, 110, 70)
        self.btn_jump = pg.Rect(W-140, 500, 110, 70)
        self.touch_map = {
            'Up': self.btn_pedal, 'Left': self.btn_left, 'Right': self.btn_right,
            'Down': self.btn_brake, 'space': self.btn_jump,
        }
        self.pause_btn_rect = pg.Rect(W-115, 10, 50, 46)
        self.menu_btn_rect = pg.Rect(W-58, 10, 50, 46)
        self.course_rects = [pg.Rect(210, 330+i*58-18, 700, 46) for i in range(len(COURSES))]
        self.resume_rect = pg.Rect(310, 330, 500, 70)
        self.retry_rect = pg.Rect(310, 225, 500, 55)
        self.next_rect = pg.Rect(310, 225, 500, 55)

    # ---- input ----

    def on_key(self, key):
        if key == pg.K_ESCAPE:
            self.mode = 'play' if self.mode == 'pause' else ('pause' if self.mode == 'play' else 'menu')
        elif self.mode == 'menu' and key in (pg.K_1, pg.K_2, pg.K_3, pg.K_KP1, pg.K_KP2, pg.K_KP3, pg.K_RETURN):
            level = {pg.K_1: 0, pg.K_KP1: 0, pg.K_2: 1, pg.K_KP2: 1, pg.K_3: 2, pg.K_KP3: 2}.get(key, 0)
            self.start(level)
        elif key == pg.K_m:
            self.mode = 'menu'
        elif key == pg.K_r and self.mode != 'menu':
            self.world.spawn(jump_held=pg.key.get_pressed()[pg.K_SPACE])
            self.mode = 'play'
            self.saved = False
        elif key == pg.K_RETURN:
            if self.world.won:
                self.start((self.world.level+1) % len(COURSES))
            elif self.world.dead:
                self.world.spawn(jump_held=False)
            elif self.mode == 'pause':
                self.mode = 'play'

    def on_tap(self, pos):
        if self.mode == 'menu':
            for i, rect in enumerate(self.course_rects):
                if rect.collidepoint(pos):
                    self.start(i)
                    return
        if self.pause_btn_rect.collidepoint(pos) and self.mode in ('play', 'pause'):
            self.mode = 'pause' if self.mode == 'play' else 'play'
            return
        if self.menu_btn_rect.collidepoint(pos) and self.mode != 'menu':
            self.mode = 'menu'
            return
        if self.mode == 'pause' and self.resume_rect.collidepoint(pos):
            self.mode = 'play'
            return
        if self.mode == 'play' and self.world.dead and self.retry_rect.collidepoint(pos):
            self.world.spawn(jump_held=False)
            return
        if self.mode == 'play' and self.world.won and self.next_rect.collidepoint(pos):
            self.start((self.world.level+1) % len(COURSES))
            return

    def update_touch(self, touch_id, finger_id, pos, active):
        key = (touch_id, finger_id)
        if active and pos is not None:
            self.contacts[key] = pos
        else:
            self.contacts.pop(key, None)

    def events(self):
        # A tap that lands and lifts within the same frame (any fast click,
        # not just automated ones) must still register for at least one
        # physics step - `pulse` guarantees that even though `contacts`
        # ends the frame empty in that case.
        pulse = set()

        def pulse_from(p):
            if self.mode == 'play':
                for key, rect in self.touch_map.items():
                    if rect.collidepoint(p):
                        pulse.add(key)

        for e in pg.event.get():
            if e.type == pg.QUIT:
                self.running = False
            elif e.type == pg.KEYDOWN:
                self.on_key(e.key)
            elif e.type in (pg.FINGERDOWN, pg.FINGERMOTION):
                p = (e.x*W, e.y*H)
                if e.type == pg.FINGERDOWN:
                    self.on_tap(p)
                    pulse_from(p)
                self.update_touch(e.touch_id, e.finger_id, p, True)
            elif e.type == pg.FINGERUP:
                self.update_touch(e.touch_id, e.finger_id, None, False)
            elif e.type == pg.MOUSEBUTTONDOWN:
                if e.button == 1 and not getattr(e, 'touch', False):
                    self.on_tap(e.pos)
                    pulse_from(e.pos)
                    self.update_touch('mouse', 'mouse', e.pos, True)
            elif e.type == pg.MOUSEMOTION and ('mouse', 'mouse') in self.contacts and not getattr(e, 'touch', False):
                self.update_touch('mouse', 'mouse', e.pos, True)
            elif e.type == pg.MOUSEBUTTONUP and e.button == 1:
                self.update_touch('mouse', 'mouse', None, False)
            elif e.type == pg.WINDOWFOCUSLOST:
                self.contacts.clear()
                if self.mode == 'play':
                    self.mode = 'pause'
        physical = set()
        held = pg.key.get_pressed()
        for name, codes in (('Up', (pg.K_UP, pg.K_w)), ('Down', (pg.K_DOWN, pg.K_s)),
                             ('Left', (pg.K_LEFT, pg.K_a)), ('Right', (pg.K_RIGHT, pg.K_d)),
                             ('space', (pg.K_SPACE,)), ('z', (pg.K_z,))):
            if any(held[c] for c in codes):
                physical.add(name)
        touch = set(pulse)
        if self.mode == 'play':
            for key, rect in self.touch_map.items():
                if any(rect.collidepoint(p) for p in self.contacts.values()):
                    touch.add(key)
        self.keys = physical | touch

    # ---- drawing ----

    def font(self, size, bold=False):
        key = (size, bold)
        if key not in self.fonts:
            f = pg.font.Font(None, max(6, round(size*1.333)))
            f.set_bold(bold)
            self.fonts[key] = f
        return self.fonts[key]

    def text(self, x, y, s, size=14, fill='#253b3a', anchor='w', bold=False):
        surf = self.font(size, bold).render(s, True, pg.Color(fill))
        rect = surf.get_rect()
        if anchor == 'center':
            rect.center = (x, y)
        else:
            rect.midleft = (x, y)
        self.screen.blit(surf, rect)

    def line(self, points, color, width=3):
        if len(points) >= 2:
            pg.draw.lines(self.screen, pg.Color(color), False, points, max(1, int(width)))

    def draw_button(self, rect, label, active=False):
        surf = pg.Surface(rect.size, pg.SRCALPHA)
        bg = (110, 175, 140, 195) if active else (32, 55, 49, 175)
        pg.draw.rect(surf, bg, surf.get_rect(), border_radius=12)
        pg.draw.rect(surf, (240, 235, 210, 140), surf.get_rect(), 2, border_radius=12)
        self.screen.blit(surf, rect.topleft)
        self.text(rect.centerx, rect.centery, label, 13, '#f3ebd2', anchor='center', bold=True)

    def panel(self, title, subtitle, compact=False):
        y = 185 if not compact else 180
        bottom = 580 if not compact else 295
        rect = pg.Rect(190, y, 740, bottom-y)
        pg.draw.rect(self.screen, '#203731', rect)
        pg.draw.rect(self.screen, '#708879', rect, 2)
        self.text(235, y+48, title, 27, '#f3ebd2', bold=True)
        self.text(235, y+88, subtitle, 11, '#b8cdbf')

    def draw(self):
        s = self.screen
        world = self.world
        cam = self.camera
        s.fill('#dde7e4')
        pg.draw.ellipse(s, '#f5f1d8', pg.Rect(820, 70, 120, 120))
        for i in range(-1, 9):
            x = i*220-(cam*.18) % 220
            pg.draw.polygon(s, '#bfceca', [(x, 490), (x+140, 245+(i % 3)*30), (x+310, 490)])
        for i in range(-1, 14):
            x = i*125-(cam*.32) % 125
            y = 355+(i % 4)*24
            pg.draw.rect(s, '#acbdb8', pg.Rect(x, y, 84, 565-y))
            for j in range(3):
                pg.draw.rect(s, '#cbd7d1', pg.Rect(x+13+j*23, y+18, 9, 10))
        for x1, y1, x2, y2 in world.segments:
            if x2 < cam-100 or x1 > cam+W+100:
                continue
            pg.draw.polygon(s, '#485955', [(x1-cam, y1), (x2-cam, y2), (x2-cam, 1000), (x1-cam, 1000)])
            self.line([(x1-cam, y1), (x2-cam, y2)], '#202f2c', 7)
            self.line([(x1-cam, y1+7), (x2-cam, y2+7)], '#a4ac8b', 3)
        for lo, hi, y in world.course['spikes']:
            for x in range(lo, hi, 18):
                pts = [(x-cam, y), (x+9-cam, y-30), (x+18-cam, y)]
                pg.draw.polygon(s, '#d7dedb', pts)
                pg.draw.polygon(s, '#52615e', pts, 2)
            pg.draw.rect(s, '#df9d3f', pg.Rect(lo-cam, y-3, hi-lo, 8))
        if world.level == 0:
            self.line([(1300-cam, 520), (1300-cam, 385)], '#52665b', 4)
            r = pg.Rect(1180-cam, 360, 240, 48)
            pg.draw.rect(s, '#edbd61', r)
            pg.draw.rect(s, '#304a43', r, 2)
            self.text(1300-cam, 384, 'SPACE x2  -  CLEAR THE SPIKES', 10, '#203731', anchor='center', bold=True)
        for sx, sy, r, travel in world.course['saws']:
            y = sy+math.sin(world.elapsed*1.8)*travel
            self.line([(sx-cam, sy-150), (sx-cam, y)], '#667b73', 6)
            pts = []
            for i in range(40):
                a = i*math.pi/20+world.elapsed*5
                rr = r if i % 2 else r*.76
                pts.append((sx-cam+math.cos(a)*rr, y+math.sin(a)*rr))
            pg.draw.polygon(s, '#e3e7df', pts)
            pg.draw.polygon(s, '#40514c', pts, 2)
            pg.draw.ellipse(s, '#d55b3d', pg.Rect(sx-cam-7, y-7, 14, 14))
        for i, (x, y) in enumerate(world.course['checkpoints']):
            self.line([(x-cam, y), (x-cam, y-95)], '#3a5550', 3)
            color = '#50a985' if world.checkpoint >= i else '#f0c86d'
            pg.draw.polygon(s, color, [(x-cam, y-95), (x+42-cam, y-82), (x-cam, y-68)])
        x = world.course['finish']-cam
        self.line([(x, 540), (x, 300)], '#304a43', 5)
        for i in range(5):
            for j in range(3):
                color = '#f7f3df' if (i+j) % 2 else '#253b36'
                pg.draw.rect(s, color, pg.Rect(x+i*15, 300+j*15, 15, 15))
        a, b = world.back, world.front
        for ex, ey, evx, evy, life, color in world.effects:
            r = max(1, life*9)
            pg.draw.ellipse(s, color, pg.Rect(ex-cam-r, ey-r, r*2, r*2))

        def loc(lx, ly):
            px, py = world.local(lx, ly)
            return (px-cam, py)
        for p in (a, b):
            x, y = p.x-cam, p.y
            pg.draw.ellipse(s, '#d4dfd9', pg.Rect(x-23, y-23, 46, 46))
            pg.draw.ellipse(s, '#253b36', pg.Rect(x-23, y-23, 46, 46), 5)
            pg.draw.ellipse(s, '#92a39c', pg.Rect(x-17, y-17, 34, 34), 2)
            for i in range(6):
                angle = p.x/22+i*math.pi/3
                self.line([(x, y), (x+19*math.cos(angle), y+19*math.sin(angle))], '#84968c', 1)
        rear, front = loc(-38, 0), loc(38, 0)
        crank, seat, bar = loc(0, -5), loc(-15, -36+world.suspension*.5), loc(28, -36+world.suspension*.3)
        self.line([rear, seat, crank, rear], '#d75d3f', 5)
        self.line([seat, bar, crank, front, bar, loc(25, -49), loc(39, -49)], '#d75d3f', 5)
        self.line([loc(-26, -39), loc(-5, -39)], '#263c35', 6)
        self.line([loc(-11*math.cos(world.pedal), -5-11*math.sin(world.pedal)),
                    loc(11*math.cos(world.pedal), -5+11*math.sin(world.pedal))], '#354740', 3)
        rider = [(p.x-cam, p.y) for p in world.ragdoll] if world.dead else [(rx-cam, ry) for rx, ry in world.rider()]
        if rider:
            self.line([rider[0], rider[5], rider[6]], '#334c61', 12)
            self.line([rider[0], rider[1]], '#d3aa49', 18)
            self.line([rider[1], rider[3], rider[4]], '#f0c19e', 8)
            hx, hy = rider[2]
            pg.draw.ellipse(s, '#f0c19e', pg.Rect(hx-12, hy-13, 24, 26))
            pg.draw.ellipse(s, '#3e4940', pg.Rect(hx-12, hy-13, 24, 26), 2)
            visor = [(hx-13.5+13.5*math.cos(math.radians(t)), hy-6-11*math.sin(math.radians(t))) for t in range(0, 181, 15)]
            pg.draw.polygon(s, '#e5e8d9', visor)
            pg.draw.lines(s, '#41534a', False, visor, 2)
            self.line([rider[6], (rider[6][0]+12, rider[6][1])], '#263c35', 7)
        pg.draw.rect(s, '#203731', pg.Rect(0, 0, W, 83))
        self.text(28, 27, 'ROUGH RIDE', 20, '#f3ebd2', bold=True)
        self.text(28, 59, world.course['name'], 10, '#a9c5b7')
        self.text(725, 29, f'{world.elapsed:05.1f}s    /    {world.deaths} CRASHES', 14, '#f3ebd2', bold=True)
        progress = max(0, min(1, a.x/world.course['finish']))
        pg.draw.rect(s, '#4a6055', pg.Rect(725, 53, 363, 5))
        pg.draw.rect(s, '#e9bb5c', pg.Rect(725, 53, int(363*progress), 5))
        pg.draw.rect(s, '#203731', pg.Rect(0, 659, W, H-659))
        self.text(28, 679, 'UP/PEDAL  LEFT-RIGHT/LEAN  SPACE/JUMP x2  DOWN/BRAKE', 10, '#e0e8d8')
        self.text(420, 29, f'JUMPS  {max(0,2-world.jumps_used)} / 2', 13, '#edbd61', bold=True)
        self.text(735, 679, 'R RETRY    ESC PAUSE    TAP ICONS ABOVE', 10, '#a9c5b7')

        if self.mode in ('play', 'pause'):
            self.draw_button(self.pause_btn_rect, 'RESUME' if self.mode == 'pause' else 'II')
        if self.mode != 'menu':
            self.draw_button(self.menu_btn_rect, 'MENU')
        if self.mode == 'play' and not world.dead and not world.won:
            self.draw_button(self.btn_pedal, 'PEDAL', 'Up' in self.keys)
            self.draw_button(self.btn_left, '<', 'Left' in self.keys)
            self.draw_button(self.btn_right, '>', 'Right' in self.keys)
            self.draw_button(self.btn_brake, 'BRAKE', 'Down' in self.keys)
            self.draw_button(self.btn_jump, 'JUMP', 'space' in self.keys)

        if self.mode == 'menu':
            self.panel('A BAD DAY TO RIDE.', 'A bicycle. A questionable route. Your sense of balance.')
            for i, course in enumerate(COURSES):
                rect = self.course_rects[i]
                hi = pg.Surface(rect.size, pg.SRCALPHA)
                pg.draw.rect(hi, (255, 255, 255, 18), hi.get_rect(), border_radius=8)
                s.blit(hi, rect.topleft)
                yy = 330+i*58
                self.text(235, yy, f'{i+1}   /   {course["name"]}', 17, '#f3ebd2', bold=True)
                record = self.records.get(str(i))
                suffix = f'   Best: {record:.1f}s' if isinstance(record, (int, float)) else ''
                self.text(235, yy+24, course['subtitle']+suffix, 10, '#adc5b7')
            self.text(235, 540, 'TAP A COURSE TO RIDE   -   OR PRESS 1-3 / ENTER', 11, '#edbd61')
        elif self.mode == 'pause':
            self.panel('TAKE A BREATHER.', 'Tap RESUME below, or use the MENU button above.')
            self.draw_button(self.resume_rect, 'RESUME')
        elif world.dead:
            self.panel('THAT LOOKED EXPENSIVE.', 'Tap RETRY below, or press R on a keyboard.', compact=True)
            self.draw_button(self.retry_rect, 'RETRY')
        elif world.won:
            self.panel('SOMEHOW, YOU MADE IT.', f'{world.elapsed:.1f}s - {world.deaths} crashes', compact=True)
            self.draw_button(self.next_rect, 'NEXT COURSE')

    # ---- loop ----

    def start(self, level):
        self.world = World(level)
        self.camera = 0
        self.saved = False
        self.mode = 'play'

    def save_records(self):
        tmp = None
        try:
            with tempfile.NamedTemporaryFile('w', dir=self.scorefile.parent, delete=False) as f:
                tmp = f.name
                json.dump(self.records, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.scorefile)
        except OSError:
            pass
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.unlink(tmp)
                except OSError:
                    pass

    async def run(self):
        try:
            while self.running:
                now = time.perf_counter()
                self.accumulator += min(.1, now-self.previous)
                self.previous = now
                self.events()
                while self.accumulator >= DT:
                    if self.mode == 'play':
                        self.world.step(self.keys)
                    self.accumulator -= DT
                target = max(0, min(self.world.back.x-310, self.world.course['finish']-750))
                self.camera += (target-self.camera)*.13
                if self.world.won and not self.saved:
                    key = str(self.world.level)
                    old = self.records.get(key)
                    if not isinstance(old, (int, float)) or self.world.elapsed < old:
                        self.records[key] = round(self.world.elapsed, 2)
                        self.save_records()
                    self.saved = True
                self.draw()
                pg.display.flip()
                await asyncio.sleep(0)
        finally:
            pg.quit()


async def main():
    await App(fullscreen=False).run()


if __name__ == '__main__':
    asyncio.run(main())
