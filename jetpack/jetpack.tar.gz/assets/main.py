#!/usr/bin/env python3
"""A 480x320, asset-free pygame Jetpack Joy Ride tribute for the Pi.
Hold to thrust up, release to fall. Weave through laser gates and zappers,
dodge missiles, collect coins. MENU returns home; X exits; P pauses.

Renders natively at the panel's own 480x320 - no small canvas scaled up -
and uses a real TTF font with antialiasing so text stays crisp on a small
screen. Input is polled every frame (mouse/touch pressed-state, not paired
down/up events) since a held thrust is much more sensitive to a dropped
touch event than flappy's original single-tap flap ever was.
"""
import os
os.environ.setdefault('SDL_VIDEO_CENTERED', '1')
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
import asyncio
import json
import math
import random
import tempfile
import time
from pathlib import Path
from array import array
import pygame as pg
import pygame.gfxdraw as gfx

W, H = 480, 320
RAIL = 16                     # top/bottom electrified rail thickness -> corridor is RAIL..H-RAIL
PLAYER_X = 110
PLAYER_R = 14
GRAVITY = 960.0
THRUST_ACCEL = -2000.0
MAX_UP_SPD, MAX_DOWN_SPD = -460.0, 520.0
BASE_SPEED, MAX_SPEED, SPEED_RAMP = 170.0, 380.0, 1.2   # px/s per meter of distance
PX_PER_METER = 24.0

OUTLINE = (26, 28, 38)
CREAM = (240, 246, 255)
BG_TOP = (52, 58, 82)
BG_BOT = (28, 31, 44)
LASER = (255, 55, 48)
ZAP = (80, 185, 255)
FONT_PATH = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'


def aacircle(surf, x, y, r, color):
    x, y, r = int(x), int(y), int(r)
    gfx.filled_circle(surf, x, y, r, color)
    gfx.aacircle(surf, x, y, r, color)


class Jetpack:
    def __init__(self, fullscreen=True, audio=True):
        pg.display.init()
        pg.font.init()
        self.screen = pg.display.set_mode((W, H), pg.FULLSCREEN if fullscreen else 0)
        pg.display.set_caption('Jetpack')
        font_src = FONT_PATH if os.path.exists(FONT_PATH) else None
        self.fonts = {n: pg.font.Font(font_src, n) for n in (18, 22, 28, 36, 48, 64)}
        self.clock = pg.time.Clock()
        self.running = True
        self.phase = 0.
        self.scroll = 0.
        self.state = 'menu'
        self.previous_state = 'play'
        self.text_cache = {}
        self.pressed = False
        self.prev_pressed = False
        self.savefile = Path(__file__).resolve().with_name('jetpack_save.json')
        self.best_m = 0
        self.total_coins = 0
        self.save_error = False
        try:
            data = json.loads(self.savefile.read_text())
            self.best_m = max(0, int(data.get('best_m', 0)))
            self.total_coins = max(0, int(data.get('total_coins', 0)))
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        self.menu_button = pg.Rect(10, 8, 92, 40)
        self.quit_button = pg.Rect(424, 8, 48, 40)
        self.pause_button = pg.Rect(360, 8, 56, 40)
        self.play_button = pg.Rect(150, 216, 180, 58)
        self.sounds = {}
        self.thrust_sound = None
        self.thrust_sound_playing = False
        if audio:
            try:
                pg.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
                for name, freq, duration in [('coin', 1300, .09), ('hit', 90, .35)]:
                    count = int(22050 * duration)
                    samples = array('h', (
                        int(3500 * (1 - i / count) * math.sin(math.tau * freq * i / 22050))
                        for i in range(count)))
                    self.sounds[name] = pg.mixer.Sound(buffer=samples.tobytes())
                loop_count = int(22050 * 0.09)
                loop_samples = array('h', (
                    int(1400 * math.sin(math.tau * 115 * i / 22050) + 500 * math.sin(math.tau * 240 * i / 22050))
                    for i in range(loop_count)))
                self.thrust_sound = pg.mixer.Sound(buffer=loop_samples.tobytes())
            except pg.error:
                pass
        self.make_art()
        self.reset()

    def reset(self):
        self.y = H / 2
        self.velocity = 0.
        self.angle = 0.
        self.thrusting = False
        self.distance_m = 0
        self.coins_run = 0
        self.obstacles = []
        self.missiles = []
        self.coins = []
        self.particles = []
        self.spawn_cooldown = 120.
        self.new_best = False
        self.set_thrust_sound(False)

    def set_thrust_sound(self, on):
        if not self.thrust_sound or on == self.thrust_sound_playing:
            return
        self.thrust_sound_playing = on
        if on and self.state == 'play':
            self.thrust_sound.play(loops=-1)
        else:
            self.thrust_sound.stop()

    def sound(self, name):
        if name in self.sounds:
            self.sounds[name].play()

    def save(self):
        temp = None
        try:
            with tempfile.NamedTemporaryFile('w', dir=self.savefile.parent, delete=False) as f:
                temp = f.name
                json.dump({'best_m': self.best_m, 'total_coins': self.total_coins}, f)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp, self.savefile)
            self.save_error = False
        except OSError:
            self.save_error = True
        finally:
            if temp and os.path.exists(temp):
                try:
                    os.unlink(temp)
                except OSError:
                    pass

    def make_art(self):
        self.bg = pg.Surface((W, H)).convert()
        for y in range(H):
            t = y / H
            c = tuple(int(BG_TOP[i] + (BG_BOT[i] - BG_TOP[i]) * t) for i in range(3))
            pg.draw.line(self.bg, c, (0, y), (W, y))
        # distant catwalk silhouettes for a bit of depth, Rough-Ride style
        self.far = pg.Surface((W, H), pg.SRCALPHA)
        for x in range(-40, W + 160, 160):
            pg.draw.rect(self.far, (70, 76, 104, 130), (x, 40, 90, H - 80), border_radius=10)
        self.beam = pg.Surface((160, H), pg.SRCALPHA)
        for x in (20, 80, 140):
            pg.draw.rect(self.beam, (100, 107, 138, 160), (x, 0, 12, H), border_radius=4)
            pg.draw.rect(self.beam, (128, 136, 168, 160), (x + 2, 0, 4, H))
        self.rail = pg.Surface((W, RAIL))
        stripe = 22
        for x in range(-stripe, W + stripe, stripe):
            pg.draw.polygon(self.rail, (35, 32, 20), [(x, 0), (x + stripe, 0), (x + stripe - RAIL, RAIL), (x - RAIL, RAIL)])
            pg.draw.polygon(self.rail, (255, 200, 40), [(x + 4, 0), (x + stripe - 6, 0), (x + stripe - 10, RAIL), (x, RAIL)])
        self.glow = pg.Surface((28, 64), pg.SRCALPHA)
        for i in range(14, 0, -1):
            a = int(90 * (i / 14) ** 2)
            pg.draw.rect(self.glow, (255, 255, 255, a), (14 - i, 0, i * 2, 64), border_radius=i)

    def player_frame(self):
        s = pg.Surface((56, 60), pg.SRCALPHA)
        skin = (233, 185, 145)
        skin_hi = (245, 205, 168)
        jacket = (150, 96, 52)
        jacket_hi = (178, 122, 70)
        pants = (54, 56, 66)
        tank = (100, 104, 118)
        tank_hi = (132, 138, 152)
        cx = 28
        # jetpack tanks, worn on the back
        pg.draw.rect(s, OUTLINE, (2, 16, 22, 32), border_radius=6)
        pg.draw.rect(s, tank, (5, 19, 8, 27), border_radius=4)
        pg.draw.rect(s, tank, (15, 19, 8, 27), border_radius=4)
        pg.draw.rect(s, tank_hi, (6, 21, 3, 14), border_radius=2)
        pg.draw.rect(s, tank_hi, (16, 21, 3, 14), border_radius=2)
        # legs / boots
        pg.draw.rect(s, OUTLINE, (18, 46, 24, 13), border_radius=4)
        pg.draw.rect(s, pants, (20, 47, 20, 10), border_radius=3)
        pg.draw.ellipse(s, OUTLINE, (16, 54, 14, 8))
        pg.draw.ellipse(s, OUTLINE, (30, 54, 14, 8))
        pg.draw.ellipse(s, (48, 48, 54), (17, 55, 12, 6))
        pg.draw.ellipse(s, (48, 48, 54), (31, 55, 12, 6))
        # jacket body
        pg.draw.rect(s, OUTLINE, (14, 18, 34, 32), border_radius=10)
        pg.draw.rect(s, jacket, (16, 20, 30, 28), border_radius=8)
        pg.draw.ellipse(s, jacket_hi, (18, 22, 16, 12))
        pg.draw.rect(s, OUTLINE, (27, 24, 4, 18), border_radius=2)
        # head - bald, round
        aacircle(s, cx + 8, 12, 13, OUTLINE)
        aacircle(s, cx + 8, 12, 11, skin)
        gfx.filled_circle(s, cx + 5, 8, 5, skin_hi)
        pg.draw.rect(s, OUTLINE, (cx + 18, 8, 3, 4), border_radius=1)
        pg.draw.line(s, (110, 72, 52), (cx + 1, 5), (cx + 7, 4), 2)
        if self.thrusting:
            flick = 6 + int(4 * math.sin(self.phase * 40))
            glow = pg.transform.scale(self.glow, (36, 40 + flick))
            s.blit(glow, (10, 46), special_flags=pg.BLEND_RGBA_ADD)
            pg.draw.polygon(s, (255, 150, 40), [(4, 48), (24, 48), (14, 48 + flick + 6)])
            pg.draw.polygon(s, (255, 210, 90), [(8, 48), (20, 48), (14, 48 + flick)])
            pg.draw.polygon(s, (230, 245, 255), [(10, 48), (18, 48), (14, 48 + flick - 6)])
        return s

    def label(self, text, x, y, size=28, color=CREAM):
        key = (text, size, color)
        if key not in self.text_cache:
            if len(self.text_cache) > 100:
                self.text_cache.clear()
            self.text_cache[key] = (self.fonts[size].render(text, True, color),
                                     self.fonts[size].render(text, True, OUTLINE))
        face, outline = self.text_cache[key]
        r = face.get_rect(center=(x, y))
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
            self.screen.blit(outline, r.move(dx, dy))
        self.screen.blit(face, r)

    def press(self, p):
        if self.quit_button.collidepoint(p):
            self.running = False
            return
        if self.menu_button.collidepoint(p):
            self.reset()
            self.state = 'menu'
            return
        if self.pause_button.collidepoint(p) and self.state in ('play', 'ready', 'pause'):
            if self.state == 'pause':
                self.state = self.previous_state
            else:
                self.previous_state = self.state
                self.state = 'pause'
            return
        if self.state in ('menu', 'over') and self.play_button.collidepoint(p):
            self.reset()
            self.state = 'ready'
        elif self.state == 'ready':
            self.state = 'play'
        elif self.state == 'pause':
            self.state = self.previous_state

    def poll_input(self):
        # Plain mouse/keyboard polling - this Pi's touchscreen already surfaces
        # touches as ordinary mouse events (see the working flappy_bird.py),
        # so there is no need to also enumerate SDL touch devices directly.
        # That was tried here and hung: pg.touch.get_num_devices() needs the
        # touch subsystem set up via a full pg.init(), which this game (like
        # the rest of this project) intentionally skips, and without it the
        # device count comes back garbage, spinning range() near-forever.
        self.pressed = bool(pg.mouse.get_pressed()[0])
        keys = pg.key.get_pressed()
        if keys[pg.K_SPACE] or keys[pg.K_UP]:
            self.pressed = True
        just_pressed = self.pressed and not self.prev_pressed
        self.prev_pressed = self.pressed
        if just_pressed:
            self.press(pg.mouse.get_pos())
        self.thrusting = self.pressed and self.state == 'play'
        self.set_thrust_sound(self.thrusting)

    def events(self):
        for e in pg.event.get():
            if e.type == pg.QUIT:
                self.running = False
            elif e.type == pg.KEYDOWN:
                if e.key in (pg.K_ESCAPE, pg.K_q):
                    self.reset()
                    self.state = 'menu'
                elif e.key == pg.K_p:
                    self.press(self.pause_button.center)
                elif e.key == pg.K_r and self.state == 'over':
                    self.reset()
                    self.state = 'ready'
            elif e.type == pg.WINDOWFOCUSLOST and self.state in ('play', 'ready'):
                self.previous_state = self.state
                self.state = 'pause'

    def explode(self):
        if self.state != 'play':
            return
        self.state = 'over'
        self.sound('hit')
        self.particles = [{
            'x': PLAYER_X, 'y': self.y,
            'vx': random.uniform(-110, 110), 'vy': random.uniform(-170, 40),
            'life': random.uniform(.35, .7),
            'color': random.choice([(255, 160, 40), (255, 90, 40), (255, 220, 90)])
        } for _ in range(24)]
        m = int(self.distance_m)
        if m > self.best_m:
            self.best_m = m
            self.new_best = True
        self.total_coins += self.coins_run
        self.save()

    def spawn_zone(self):
        kind = random.choices(['laser', 'zapper', 'missile', 'clear'], weights=[32, 24, 22, 22])[0]
        top, bot = RAIL + 8, H - RAIL - 8
        if kind in ('laser', 'zapper'):
            gap = 100 if kind == 'laser' else 82
            center = random.randint(top + gap // 2, bot - gap // 2)
            self.obstacles.append({
                'kind': kind, 'x': float(W + 30), 'w': 18,
                'center': float(center), 'base': float(center), 'gap': gap,
                'phase': random.uniform(0, math.tau),
            })
            for dy in (-28, 0, 28):
                self.coins.append({'x': W + 30, 'y': center + dy, 'taken': False})
            self.spawn_cooldown = random.uniform(240, 350)
        elif kind == 'missile':
            self.missiles.append({'x': float(W + 50), 'y': self.y, 'timer': 0.6, 'state': 'warn'})
            self.spawn_cooldown = random.uniform(260, 380)
        else:
            base_y = random.randint(top + 20, bot - 20)
            for i in range(5):
                self.coins.append({
                    'x': W + 30 + i * 30,
                    'y': base_y + math.sin(i * 1.1) * 52,
                    'taken': False,
                })
            self.spawn_cooldown = random.uniform(220, 300)

    def update(self, dt):
        if self.state == 'pause':
            return
        dt = min(dt, .05)
        self.phase += dt
        if self.state in ('menu', 'ready'):
            self.y = H / 2 + math.sin(self.phase * 3) * 16
            self.angle = math.sin(self.phase * 3) * 8
        if self.state != 'play':
            return

        accel = GRAVITY + (THRUST_ACCEL if self.thrusting else 0)
        self.velocity = max(MAX_UP_SPD, min(MAX_DOWN_SPD, self.velocity + accel * dt))
        self.y += self.velocity * dt
        target_angle = -22 if self.thrusting else min(75, self.velocity * 0.16)
        self.angle += (target_angle - self.angle) * min(1, dt * 10)

        if self.y < RAIL or self.y > H - RAIL:
            self.y = max(RAIL, min(H - RAIL, self.y))
            self.explode()
            return

        speed = min(MAX_SPEED, BASE_SPEED + self.distance_m * SPEED_RAMP)
        self.scroll = (self.scroll + speed * dt) % 80
        self.distance_m += speed * dt / PX_PER_METER

        self.spawn_cooldown -= speed * dt
        if self.spawn_cooldown <= 0:
            self.spawn_zone()

        for o in self.obstacles:
            o['x'] -= speed * dt
            if o['kind'] == 'zapper':
                amp = 44
                o['center'] = max(RAIL + o['gap'] // 2 + 8, min(H - RAIL - o['gap'] // 2 - 8,
                                   o['base'] + amp * math.sin(self.phase * 2.2 + o['phase'])))
        self.obstacles = [o for o in self.obstacles if o['x'] > -40]

        for m in self.missiles:
            if m['state'] == 'warn':
                m['timer'] -= dt
                if m['timer'] <= 0:
                    m['state'] = 'fly'
                    m['y'] = self.y
            else:
                m['x'] -= speed * 2.3 * dt
        self.missiles = [m for m in self.missiles if m['x'] > -60]

        for c in self.coins:
            c['x'] -= speed * dt
        self.coins = [c for c in self.coins if c['x'] > -40 and not c['taken']]

        for c in self.coins:
            if math.hypot(c['x'] - PLAYER_X, c['y'] - self.y) < PLAYER_R + 12:
                c['taken'] = True
                self.coins_run += 1
                self.sound('coin')

        for o in self.obstacles:
            if o['x'] - o['w'] / 2 < PLAYER_X + PLAYER_R and o['x'] + o['w'] / 2 > PLAYER_X - PLAYER_R:
                if self.y - PLAYER_R < o['center'] - o['gap'] / 2 or self.y + PLAYER_R > o['center'] + o['gap'] / 2:
                    self.explode()
                    return

        for m in self.missiles:
            if m['state'] == 'fly' and math.hypot(m['x'] - PLAYER_X, m['y'] - self.y) < PLAYER_R + 10:
                self.explode()
                return

    def draw_beam(self, x, top, bottom, color):
        s = self.screen
        dim = tuple(c // 3 for c in color)
        for y0, y1 in ((0, top), (bottom, H)):
            if y1 <= y0:
                continue
            r = pg.Rect(int(x) - 9, int(y0), 18, int(y1 - y0))
            pg.draw.rect(s, OUTLINE, r.inflate(4, 0))
            pg.draw.rect(s, dim, r)
            pg.draw.rect(s, color, r.inflate(-8, 0))
            pg.draw.rect(s, CREAM, r.inflate(-14, 0))
            glow = pg.transform.scale(self.glow, (40, int(y1 - y0)))
            tinted = glow.copy()
            tinted.fill((*color, 255), special_flags=pg.BLEND_RGBA_MULT)
            s.blit(tinted, (int(x) - 20, int(y0)), special_flags=pg.BLEND_RGBA_ADD)
        pg.draw.rect(s, OUTLINE, (int(x) - 11, int(top) - 7, 22, 7), border_radius=3)
        pg.draw.rect(s, OUTLINE, (int(x) - 11, int(bottom), 22, 7), border_radius=3)

    def draw_missile(self, m):
        s = self.screen
        if m['state'] == 'warn':
            pulse = 0.5 + 0.5 * math.sin(self.phase * 18)
            if pulse > 0.35:
                col = (255, int(60 + 60 * pulse), 40)
                pg.draw.polygon(s, col, [(W - 12, m['y'] - 14), (W - 12, m['y'] + 14), (W - 32, m['y'])])
        else:
            x, y = int(m['x']), int(m['y'])
            pg.draw.polygon(s, (255, 140, 60), [(x + 20, y - 6), (x + 20, y + 6), (x + 44, y)])
            pg.draw.polygon(s, (255, 200, 120), [(x + 24, y - 4), (x + 24, y + 4), (x + 40, y)])
            pg.draw.rect(s, OUTLINE, (x - 12, y - 8, 32, 16), border_radius=4)
            pg.draw.rect(s, (160, 160, 172), (x - 10, y - 6, 28, 12), border_radius=3)
            pg.draw.polygon(s, OUTLINE, [(x - 12, y - 8), (x - 12, y + 8), (x - 28, y)])
            for i in range(4):
                tx = x - 28 - i * 12
                aacircle(s, tx, y + random.randint(-3, 3), 6 - i, (255, 170 - i * 30, 40))

    def draw(self):
        s = self.screen
        s.blit(self.bg, (0, 0))
        s.blit(self.far, (0, 0))
        shift = int(self.scroll * 0.6) % 160
        s.blit(self.beam, (-shift, 0))
        s.blit(self.beam, (160 - shift, 0))
        s.blit(self.beam, (320 - shift, 0))
        s.blit(self.beam, (480 - shift, 0))

        for c in self.coins:
            if not c['taken']:
                cx, cy = int(c['x']), int(c['y'])
                wobble = max(2, abs(math.cos(self.phase * 5 + cx)) * 12)
                aacircle(s, cx, cy, 12, OUTLINE)
                gfx.filled_ellipse(s, cx, cy, int(wobble), 10, (255, 215, 40))
                gfx.aaellipse(s, cx, cy, int(wobble), 10, (255, 215, 40))
                gfx.filled_ellipse(s, cx - 2, cy - 2, max(1, int(wobble * .4)), 4, (255, 245, 190))

        for o in self.obstacles:
            color = LASER if o['kind'] == 'laser' else ZAP
            self.draw_beam(o['x'], o['center'] - o['gap'] / 2, o['center'] + o['gap'] / 2, color)

        for m in self.missiles:
            self.draw_missile(m)

        s.blit(self.rail, (0, 0))
        s.blit(self.rail, (0, H - RAIL))

        if self.state != 'over' or self.particles:
            frame = self.player_frame()
            rot = pg.transform.rotate(frame, self.angle)
            s.blit(rot, rot.get_rect(center=(PLAYER_X, int(self.y))))

        for p in self.particles[:]:
            p['life'] -= 1 / 60
            p['x'] += p['vx'] / 60
            p['y'] += p['vy'] / 60
            p['vy'] += 320 / 60
            if p['life'] <= 0:
                self.particles.remove(p)
            else:
                aacircle(s, p['x'], p['y'], max(1, p['life'] * 10), p['color'])

        if self.state == 'menu':
            self.label('JETPACK', 240, 66, 64, (255, 214, 60))
            self.label(f'BEST {self.best_m}m', 150, 122, 28)
            self.label(f'COINS {self.total_coins}', 330, 122, 28)
            self.label('HOLD TO FLY', 240, 182, 28)
        elif self.state == 'ready':
            self.label('GET READY', 240, 92, 48, (255, 214, 60))
            self.label('HOLD TO FLY', 240, 198, 36)
        elif self.state == 'play':
            plaque = pg.Surface((120, 42), pg.SRCALPHA)
            plaque.fill((10, 12, 18, 150))
            s.blit(plaque, (8, 52))
            self.label(f'{int(self.distance_m)}m', 68, 73, 36)
            plaque2 = pg.Surface((120, 44), pg.SRCALPHA)
            plaque2.fill((10, 12, 18, 150))
            s.blit(plaque2, (210, 8))
            aacircle(s, 232, 29, 11, OUTLINE)
            gfx.filled_circle(s, 232, 29, 9, (255, 215, 40))
            self.label(str(self.coins_run), 265, 29, 28)
        elif self.state == 'over':
            self.label('CRASHED', 240, 56, 36, (255, 90, 60))
            pg.draw.rect(s, OUTLINE, (72, 90, 336, 126), border_radius=10)
            pg.draw.rect(s, (224, 213, 159), (76, 94, 328, 118), border_radius=8)
            self.label(f'DISTANCE {int(self.distance_m)}m', 240, 122, 28, OUTLINE)
            best_text = f'BEST {self.best_m}m' + (' NEW!' if self.new_best else '')
            self.label(best_text, 240, 154, 28, (190, 50, 40) if self.new_best else OUTLINE)
            self.label(f'COINS +{self.coins_run}', 240, 186, 28, OUTLINE)
        elif self.state == 'pause':
            self.label('PAUSED', 240, 116, 48)
            self.label('TAP TO RESUME', 240, 176, 28)

        if self.state in ('menu', 'over'):
            pg.draw.rect(s, OUTLINE, self.play_button.move(0, 4), border_radius=8)
            pg.draw.rect(s, (231, 124, 57), self.play_button, border_radius=8)
            pg.draw.rect(s, CREAM, self.play_button.inflate(-8, -8), 2, border_radius=6)
            self.label('PLAY' if self.state == 'menu' else 'RETRY', *self.play_button.center, 36)
        if self.state != 'menu':
            pg.draw.rect(s, OUTLINE, self.menu_button, border_radius=6)
            self.label('MENU', *self.menu_button.center, 22)
        pg.draw.rect(s, OUTLINE, self.quit_button.move(0, 3), border_radius=6)
        pg.draw.rect(s, (220, 45, 45), self.quit_button, border_radius=6)
        self.label('X', *self.quit_button.center, 28, CREAM)
        if self.state in ('play', 'ready', 'pause'):
            pg.draw.rect(s, OUTLINE, self.pause_button, border_radius=6)
            self.label('II', *self.pause_button.center, 22)
        if self.save_error:
            self.label('SAVE FAILED', 240, 270, 22)

    async def run(self):
        previous = time.perf_counter()
        try:
            while self.running:
                self.clock.tick(60)
                now = time.perf_counter()
                dt = now - previous
                previous = now
                self.events()
                self.poll_input()
                self.update(dt)
                self.draw()
                pg.display.flip()
                await asyncio.sleep(0)
        finally:
            pg.quit()


async def main():
    await Jetpack(fullscreen=False).run()


if __name__ == '__main__':
    asyncio.run(main())
