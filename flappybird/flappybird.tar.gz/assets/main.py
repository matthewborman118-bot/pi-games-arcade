#!/usr/bin/env python3
"""A 480x320, asset-free pygame Flappy Bird tribute for the Pi.
Tap / Space / Up to flap. MENU returns home; X exits; P pauses.
Original procedural pixel art, time-based physics and persistent best score.
"""
import os
os.environ.setdefault('SDL_VIDEO_CENTERED','1')
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT','1')
import asyncio
import math
import random
import tempfile
import time
from pathlib import Path
from array import array
import pygame as pg

W,H,GROUND=240,160,140
BIRD_X=60
SPEED,GRAVITY,FLAP=65.,430.,-143.
GAP,SPACING=52,100
OUTLINE=(72,57,42)
CREAM=(250,243,206)

class Flappy:
    def __init__(self,fullscreen=True,audio=True):
        pg.display.init(); pg.font.init()
        self.screen=pg.display.set_mode((480,320),pg.FULLSCREEN if fullscreen else 0)
        pg.display.set_caption('Flappy Bird')
        self.scene=pg.Surface((W,H)).convert()
        self.fonts={n:pg.font.Font(None,n) for n in (16,20,26,36,46)}
        self.clock=pg.time.Clock(); self.running=True; self.phase=0.; self.scroll=0.
        self.state='menu'; self.previous_state='play'; self.text_cache={}; self.rotations={}
        self.scorefile=Path(__file__).resolve().with_name('flappy_highscore.txt')
        self.best=0; self.save_error=False
        try: self.best=max(0,int(self.scorefile.read_text().strip()))
        except (OSError,ValueError): pass
        self.menu_button=pg.Rect(8,7,68,30); self.quit_button=pg.Rect(437,7,36,30)
        self.pause_button=pg.Rect(389,7,38,30)
        self.play_button=pg.Rect(167,214,146,44)
        self.sounds={}
        if audio:
            try:
                pg.mixer.init(frequency=22050,size=-16,channels=1,buffer=512)
                for name,freq,duration in [('flap',650,.055),('point',1150,.11),('hit',130,.16)]:
                    count=int(22050*duration)
                    samples=array('h',(int(3500*(1-i/count)*math.sin(math.tau*(freq*i/22050+(240*i*i/(22050*count) if name=='flap' else 0)))) for i in range(count)))
                    self.sounds[name]=pg.mixer.Sound(buffer=samples.tobytes())
            except pg.error: pass
        self.make_art(); self.reset()

    def reset(self):
        self.y=70.; self.velocity=0.; self.angle=0.; self.score=0; self.pipes=[]
        self.flash=0.; self.dead_time=0.; self.new_best=False

    def sound(self,name):
        if name in self.sounds: self.sounds[name].play()

    def save(self):
        temp=None
        try:
            with tempfile.NamedTemporaryFile('w',dir=self.scorefile.parent,delete=False) as f:
                temp=f.name; f.write(str(self.best)); f.flush(); os.fsync(f.fileno())
            os.replace(temp,self.scorefile); self.save_error=False
        except OSError: self.save_error=True
        finally:
            if temp and os.path.exists(temp):
                try: os.unlink(temp)
                except OSError: pass

    def new_surface(self,w,h):
        s=pg.Surface((w,h)).convert(); s.fill((255,0,255))
        s.set_colorkey((255,0,255),pg.RLEACCEL); return s

    def make_art(self):
        self.birds=[]
        # Block-built pixel bird with three wing frames and an orange bill.
        for wing in (0,2,4):
            s=self.new_surface(22,17)
            pg.draw.rect(s,OUTLINE,(4,3,12,11)); pg.draw.rect(s,OUTLINE,(2,5,16,7))
            pg.draw.rect(s,(250,204,57),(4,4,12,9)); pg.draw.rect(s,(250,204,57),(3,6,14,5))
            pg.draw.rect(s,(255,237,116),(5,4,7,3)); pg.draw.rect(s,(234,166,37),(5,11,10,2))
            pg.draw.rect(s,OUTLINE,(12,2,6,9)); pg.draw.rect(s,(255,255,235),(13,3,4,7))
            pg.draw.rect(s,OUTLINE,(16,5,2,4))
            pg.draw.rect(s,OUTLINE,(13,10,9,4)); pg.draw.rect(s,(239,111,47),(14,11,7,2))
            pg.draw.rect(s,OUTLINE,(1,7+wing//2,8,5)); pg.draw.rect(s,(255,243,174),(2,8+wing//2,6,3))
            self.birds.append(s)
        self.sky=pg.Surface((W,H)).convert(); self.sky.fill((113,197,205))
        self.cloud=self.new_surface(280,90)
        rng=random.Random(42)
        for x in range(0,280,22):
            y=rng.randrange(22,44)
            pg.draw.rect(self.cloud,(231,249,220),(x,y,29,90-y))
            pg.draw.rect(self.cloud,(231,249,220),(x+5,y-6,18,8))
            pg.draw.rect(self.cloud,(249,253,232),(x+6,y-5,16,2))
        self.city=self.new_surface(280,56)
        for x in range(0,280,17):
            y=rng.randrange(3,26)
            pg.draw.rect(self.city,(151,210,180),(x,y,14,56-y))
            pg.draw.rect(self.city,(177,227,191),(x+1,y+1,11,55-y))
            for wy in range(y+5,53,8):
                for wx in (x+3,x+8): pg.draw.rect(self.city,(143,200,174),(wx,wy,3,4))
        self.bush=self.new_surface(280,26)
        for x in range(0,280,14):
            pg.draw.rect(self.bush,(94,172,99),(x,8,19,18))
            pg.draw.rect(self.bush,(111,192,105),(x+2,5,15,21))
            pg.draw.rect(self.bush,(129,207,112),(x+5,3,9,4))
        self.ground=pg.Surface((256,20)).convert(); self.ground.fill((222,211,146))
        pg.draw.rect(self.ground,OUTLINE,(0,0,256,2))
        pg.draw.rect(self.ground,(217,239,130),(0,2,256,3))
        pg.draw.rect(self.ground,(115,180,68),(0,5,256,5))
        for x in range(-10,260,10):
            pg.draw.polygon(self.ground,(180,220,89),[(x,5),(x+5,5),(x+1,10),(x-4,10)])
        pg.draw.line(self.ground,(247,238,181),(0,11),(256,11),2)
        for x in range(2,256,12): pg.draw.rect(self.ground,(204,191,125),(x,16,3,2))

    def label(self,text,x,y,size=26,color=CREAM):
        key=(text,size,color)
        if key not in self.text_cache:
            if len(self.text_cache)>100: self.text_cache.clear()
            self.text_cache[key]=(self.fonts[size].render(text,False,color),self.fonts[size].render(text,False,OUTLINE))
        face,outline=self.text_cache[key]; r=face.get_rect(center=(x,y))
        for dx,dy in ((-2,0),(2,0),(0,-2),(0,2)):
            self.screen.blit(outline,r.move(dx,dy))
        self.screen.blit(face,r)

    def flap(self):
        if self.state=='ready':
            self.state='play'; self.pipes=[dict(x=260.,center=74.,scored=False)]
        if self.state=='play': self.velocity=FLAP; self.sound('flap')

    def press(self,p):
        if self.quit_button.collidepoint(p): self.running=False; return
        if self.menu_button.collidepoint(p): self.reset(); self.state='menu'; return
        if self.pause_button.collidepoint(p) and self.state in ('play','ready','pause'):
            if self.state=='pause': self.state=self.previous_state
            else: self.previous_state=self.state; self.state='pause'
            return
        if self.state=='menu':
            if self.play_button.collidepoint(p): self.reset(); self.state='ready'
        elif self.state=='over':
            if self.play_button.collidepoint(p): self.reset(); self.state='ready'
        elif self.state=='pause': self.state=self.previous_state
        else: self.flap()

    def events(self):
        for e in pg.event.get():
            if e.type==pg.QUIT: self.running=False
            elif e.type==pg.KEYDOWN:
                if e.key in (pg.K_ESCAPE,pg.K_q): self.reset(); self.state='menu'
                elif e.key==pg.K_p:
                    self.press(self.pause_button.center)
                elif e.key in (pg.K_SPACE,pg.K_UP,pg.K_RETURN):
                    if self.state in ('menu','over'): self.reset(); self.state='ready'
                    elif self.state=='pause': self.state=self.previous_state
                    else: self.flap()
            elif e.type==pg.FINGERDOWN: self.press((e.x*480,e.y*320))
            elif e.type==pg.MOUSEBUTTONDOWN and e.button==1 and not getattr(e,'touch',False): self.press(e.pos)
            elif e.type==pg.WINDOWFOCUSLOST and self.state in ('play','ready'):
                self.previous_state=self.state; self.state='pause'

    def die(self):
        if self.state!='play': return
        self.state='fall'; self.flash=.09; self.velocity=max(0,self.velocity)
        self.sound('hit')
        if self.score>self.best:
            self.best=self.score; self.new_best=True; self.save()

    def collision(self,pipe):
        # Circular hitbox against the actual cap width, slightly forgiving
        # around the feather tips; collision and art use the same geometry.
        left=pipe['x']-2; right=pipe['x']+28
        top=pipe['center']-GAP/2; bottom=pipe['center']+GAP/2
        nearest_x=max(left,min(right,BIRD_X))
        for a,b in ((0,top),(bottom,GROUND)):
            nearest_y=max(a,min(b,self.y))
            if (BIRD_X-nearest_x)**2+(self.y-nearest_y)**2<6.5**2: return True
        return False

    def update(self,dt):
        if self.state=='pause': return
        dt=min(dt,.12); self.phase+=dt
        self.flash=max(0,self.flash-dt)
        if self.state in ('menu','ready','play'): self.scroll=(self.scroll+SPEED*dt)%2800
        if self.state in ('menu','ready'): self.y=70+math.sin(self.phase*4)*3; self.angle=0
        if self.state not in ('play','fall'): return
        steps=max(1,math.ceil(dt*120)); h=dt/steps
        for _ in range(steps):
            self.velocity=min(220,self.velocity+GRAVITY*h); self.y+=self.velocity*h
            target=25 if self.velocity<0 else max(-90,25-self.velocity*.58)
            self.angle+=(target-self.angle)*min(1,h*12)
            if self.state=='play':
                for pipe in self.pipes: pipe['x']-=SPEED*h
                if self.pipes[-1]['x']<=W-SPACING:
                    last=self.pipes[-1]['center']
                    self.pipes.append(dict(x=self.pipes[-1]['x']+SPACING,center=max(43,min(103,last+random.uniform(-28,28))),scored=False))
                self.pipes=[p for p in self.pipes if p['x']>-32]
                if self.y<6.5 or self.y>=GROUND-6.5 or any(self.collision(p) for p in self.pipes): self.die()
                if self.state=='play':
                    for pipe in self.pipes:
                        if not pipe['scored'] and pipe['x']+28<BIRD_X:
                            pipe['scored']=True; self.score+=1; self.sound('point')
            if self.state=='fall' and self.y>=GROUND-7:
                self.y=GROUND-7; self.state='over'; break

    def pipe(self,x,top,bottom):
        s=self.scene; x=int(x)
        for y,height,cap in ((0,int(top),int(top)-9),(int(bottom),GROUND-int(bottom),int(bottom))):
            pg.draw.rect(s,OUTLINE,(x,y,26,height))
            pg.draw.rect(s,(88,143,45),(x+1,y,24,height))
            pg.draw.rect(s,(149,205,66),(x+3,y,17,height))
            pg.draw.rect(s,(212,238,118),(x+4,y,3,height))
            pg.draw.rect(s,(121,181,53),(x+19,y,4,height))
            pg.draw.rect(s,OUTLINE,(x-2,cap,30,9))
            pg.draw.rect(s,(87,139,41),(x-1,cap+1,28,7))
            pg.draw.rect(s,(154,209,70),(x,cap+1,25,5))
            pg.draw.rect(s,(215,239,120),(x+1,cap+1,3,5))

    def draw(self):
        s=self.scene; s.blit(self.sky,(0,0))
        for layer,y,factor in ((self.cloud,49,.08),(self.city,84,.15),(self.bush,114,.3)):
            shift=int(self.scroll*factor)%280
            s.blit(layer,(-shift,y)); s.blit(layer,(280-shift,y))
        for pipe in self.pipes: self.pipe(pipe['x'],pipe['center']-GAP/2,pipe['center']+GAP/2)
        frame=int(self.phase*10)%3 if self.state not in ('fall','over') else 1
        angle=round(self.angle/5)*5; key=(frame,angle)
        if key not in self.rotations: self.rotations[key]=pg.transform.rotate(self.birds[frame],angle)
        bird=self.rotations[key]; s.blit(bird,bird.get_rect(center=(BIRD_X,int(self.y))))
        shift=int(self.scroll)%10; s.blit(self.ground,(-shift,GROUND))
        if self.flash>0: s.fill(CREAM)
        pg.transform.scale(s,(480,320),self.screen)
        if self.state=='menu':
            self.label('FLAPPY BIRD',240,84,46,(249,221,93))
            self.label('BEST  '+str(self.best),240,125,20)
            self.label('Tap to flap. Fly through the pipes.',240,188,20)
        elif self.state=='ready':
            self.label('GET READY!',240,86,36,(249,221,93))
            self.label('TAP TO FLAP',240,200,26)
            self.label('SPACE or UP works too',240,228,16)
        elif self.state=='over':
            self.label('GAME OVER',240,76,36,(238,139,67))
            pg.draw.rect(self.screen,OUTLINE,(112,103,256,101),border_radius=6)
            pg.draw.rect(self.screen,(224,213,159),(116,107,248,93),border_radius=4)
            self.label('MEDAL',169,125,16)
            medal=(245,199,68) if self.score>=20 else ((201,211,210) if self.score>=10 else ((196,132,76) if self.score>=5 else (187,182,147)))
            pg.draw.circle(self.screen,OUTLINE,(169,162),25)
            pg.draw.circle(self.screen,medal,(169,162),22)
            pg.draw.circle(self.screen,CREAM,(169,162),17,2)
            self.label(str(self.score) if self.score>=5 else '-',169,162,20)
            self.label('SCORE  '+str(self.score),282,133,26)
            self.label('BEST   '+str(self.best),282,166,26)
            if self.new_best: self.label('NEW!',337,190,16,(238,104,49))
        elif self.state=='pause':
            self.label('PAUSED',240,116,36)
            self.label('Tap to resume',240,166,26)
        else: self.label(str(self.score),240,45,46)
        if self.state in ('menu','over'):
            pg.draw.rect(self.screen,OUTLINE,self.play_button.move(0,3),border_radius=5)
            pg.draw.rect(self.screen,(231,124,57),self.play_button,border_radius=5)
            pg.draw.rect(self.screen,CREAM,self.play_button.inflate(-6,-6),2,border_radius=3)
            self.label('PLAY' if self.state=='menu' else 'RETRY',240,235,26)
        if self.state!='menu':
            pg.draw.rect(self.screen,OUTLINE,self.menu_button,border_radius=4); self.label('MENU',42,22,20)
        pg.draw.rect(self.screen,OUTLINE,self.quit_button,border_radius=4); self.label('X',455,22,26)
        if self.state in ('play','ready','pause'):
            pg.draw.rect(self.screen,OUTLINE,self.pause_button,border_radius=4); self.label('II',408,22,20)
        if self.save_error: self.label('Score could not be saved',240,270,16)

    async def run(self):
        previous=time.perf_counter()
        try:
            while self.running:
                self.clock.tick(60); now=time.perf_counter(); dt=now-previous; previous=now
                state=self.state; self.events()
                if state==self.state: self.update(dt)
                self.draw(); pg.display.flip()
                await asyncio.sleep(0)
        finally: pg.quit()

async def main():
    await Flappy(fullscreen=False).run()

if __name__=='__main__': asyncio.run(main())
