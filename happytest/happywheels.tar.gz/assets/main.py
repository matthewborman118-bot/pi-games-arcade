import asyncio
import pygame
import math
import random

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 480, 320
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Happy Wheels Prototype")

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 120, 255)
GRAY = (128, 128, 128)

# Physics constants
GRAVITY = 0.5
FRICTION = 0.99
ACCELERATION = 0.8
BRAKE_FORCE = 1.2
TORQUE = 0.15

# Camera / zoom settings
zoom = 2.5
cam_x = 0
cam_y = 0

class Terrain:
    def __init__(self):
        self.points = []
        self.generate_terrain()
    
    def generate_terrain(self):
        # Generate a bumpy terrain with some hills and valleys
        x = 0
        y_base = HEIGHT - 100
        self.points.append((0, y_base))
        
        # Flat, safe start for first 200 pixels
        for i in range(200):
            x += 1
            self.points.append((x, y_base))
        
        while x < WIDTH:
            # Create varied terrain segments
            segment_length = random.randint(30, 80)
            y_change = random.randint(-40, 40)
            y_new = max(HEIGHT - 150, min(HEIGHT - 50, y_base + y_change))
            
            for i in range(segment_length):
                x += 1
                y_interpolated = y_base + (y_new - y_base) * (i / segment_length)
                self.points.append((x, y_interpolated))
            
            y_base = y_new
        
        # Add some random bumps only after the flat zone
        for _ in range(5):
            bump_x = random.randint(250, WIDTH - 50)
            bump_height = random.randint(20, 50)
            for i in range(20):
                x = bump_x - 10 + i
                if 0 <= x < len(self.points):
                    bump_effect = bump_height * (1 - abs(i - 10) / 10)
                    self.points[x] = (x, self.points[x][1] - bump_effect)
        
        # Extend to screen width
        while len(self.points) < WIDTH:
            self.points.append((len(self.points), HEIGHT - 100))
    
    def get_height_at(self, x):
        x = max(0, min(len(self.points) - 1, int(x)))
        return self.points[x][1]
    
    def draw(self, screen):
        # Draw terrain outline
        for i in range(len(self.points) - 1):
            p1 = self.points[i]
            p2 = self.points[i+1]
            pygame.draw.line(screen, GRAY,
                            ((p1[0] - cam_x) * zoom, (p1[1] - cam_y) * zoom),
                            ((p2[0] - cam_x) * zoom, (p2[1] - cam_y) * zoom),
                            max(1, int(3 * zoom)))
        
        # Fill terrain
        poly_points = []
        poly_points.append(((0 - cam_x) * zoom, (HEIGHT - cam_y) * zoom))
        for p in self.points:
            poly_points.append(((p[0] - cam_x) * zoom, (p[1] - cam_y) * zoom))
        poly_points.append(((WIDTH - cam_x) * zoom, (HEIGHT - cam_y) * zoom))
        pygame.draw.polygon(screen, (100, 100, 100), poly_points)

class Rider:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = 0
        self.vy = 0
        self.on_vehicle = True
        self.fall_timer = 0
    
    def update(self, vehicle):
        if self.on_vehicle:
            # Rider moves with vehicle, seated on seat
            self.x = vehicle.x + 15
            self.y = vehicle.y - 15
        else:
            # Apply gravity
            self.vy += GRAVITY
            self.x += self.vx
            self.y += self.vy
            
            # Simple ground collision
            terrain_height = terrain.get_height_at(self.x)
            if self.y > terrain_height - 10:
                self.y = terrain_height - 10
                self.vy *= -0.3  # Bounce
                self.vx *= FRICTION
            
            self.fall_timer += 1
    
    def draw(self, screen, vehicle=None):
        cx = int((self.x - cam_x) * zoom)
        cy = int((self.y - cam_y) * zoom)
        
        # Head with helmet
        pygame.draw.circle(screen, RED, (cx, cy), int(10 * zoom))
        pygame.draw.circle(screen, (220, 220, 220), (cx, cy), int(7 * zoom))
        
        # Torso (visible body)
        pygame.draw.rect(screen, BLUE, (cx - int(8*zoom), cy + int(8*zoom), int(16*zoom), int(22*zoom)))
        
        # Arms
        pygame.draw.line(screen, WHITE,
                        (cx - int(8*zoom), cy + int(12*zoom)),
                        (cx - int(20*zoom), cy + int(15*zoom)),
                        max(1, int(3*zoom)))
        pygame.draw.line(screen, WHITE,
                        (cx + int(8*zoom), cy + int(12*zoom)),
                        (cx + int(20*zoom), cy + int(15*zoom)),
                        max(1, int(3*zoom)))
        
        # Legs
        pygame.draw.line(screen, BLACK,
                        (cx - int(4*zoom), cy + int(30*zoom)),
                        (cx - int(12*zoom), cy + int(45*zoom)),
                        max(1, int(3*zoom)))
        pygame.draw.line(screen, BLACK,
                        (cx + int(4*zoom), cy + int(30*zoom)),
                        (cx + int(12*zoom), cy + int(45*zoom)),
                        max(1, int(3*zoom)))
        
        # Joints / attachment to bike seat when on vehicle
        if self.on_vehicle and vehicle is not None:
            seat_x = int((vehicle.x - cam_x) * zoom)
            seat_y = int((vehicle.y - 5 - cam_y) * zoom)
            # Joint circles at rider's bottom
            pygame.draw.circle(screen, BLACK, (cx, cy + int(30*zoom)), int(3*zoom))
            # Line connecting rider to seat
            pygame.draw.line(screen, BLACK,
                            (cx, cy + int(30*zoom)),
                            (seat_x, seat_y),
                            max(1, int(2*zoom)))

class Vehicle:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vx = 0
        self.vy = 0
        self.angle = 0  # Radians
        self.angular_velocity = 0
        self.wheel_base = 30
        self.wheel_radius = 10
        
    def update(self):
        # Apply gravity
        self.vy += GRAVITY
        
        # Update position
        self.x += self.vx
        self.y += self.vy
        
        # Update angle based on angular velocity
        self.angle += self.angular_velocity
        self.angular_velocity *= FRICTION
        
        # Wheel-ground collision (simplified)
        front_wheel_x = self.x + math.cos(self.angle) * self.wheel_base/2
        front_wheel_y = self.y + math.sin(self.angle) * self.wheel_base/2
        rear_wheel_x = self.x - math.cos(self.angle) * self.wheel_base/2
        rear_wheel_y = self.y - math.sin(self.angle) * self.wheel_base/2
        
        # Check front wheel collision
        front_terrain_y = terrain.get_height_at(front_wheel_x)
        if front_wheel_y + self.wheel_radius > front_terrain_y:
            overlap = (front_wheel_y + self.wheel_radius) - front_terrain_y
            self.y -= overlap
            self.vy *= -0.3
            # Add some bounce effect
            self.angular_velocity += overlap * 0.01
        
        # Check rear wheel collision
        rear_terrain_y = terrain.get_height_at(rear_wheel_x)
        if rear_wheel_y + self.wheel_radius > rear_terrain_y:
            overlap = (rear_wheel_y + self.wheel_radius) - rear_terrain_y
            self.y -= overlap
            self.vy *= -0.3
            self.angular_velocity -= overlap * 0.01
        
        # Keep vehicle on screen horizontally
        self.x = max(20, min(WIDTH - 20, self.x))
    
    def accelerate(self):
        # Accelerate in the direction the vehicle is facing
        force_x = math.cos(self.angle) * ACCELERATION
        self.vx += force_x
        # Add some visual rotation when accelerating
        self.angular_velocity -= force_x * 0.02
    
    def brake(self):
        # Brake opposite to current velocity direction
        if abs(self.vx) > 0.1:
            brake_dir = -1 if self.vx > 0 else 1
            self.vx += brake_dir * BRAKE_FORCE
        else:
            # If stopped, accelerate backwards slightly
            self.vx -= math.cos(self.angle) * ACCELERATION * 0.5
    
    def lean_forward(self):
        self.angular_velocity -= TORQUE
    
    def lean_backward(self):
        self.angular_velocity += TORQUE
    
    def draw(self, screen):
        # Wheel positions
        front_wheel_x = self.x + math.cos(self.angle) * self.wheel_base/2
        front_wheel_y = self.y + math.sin(self.angle) * self.wheel_base/2
        rear_wheel_x = self.x - math.cos(self.angle) * self.wheel_base/2
        rear_wheel_y = self.y - math.sin(self.angle) * self.wheel_base/2
        
        # Draw wheels with tires and rims
        for wx, wy in [(front_wheel_x, front_wheel_y), (rear_wheel_x, rear_wheel_y)]:
            cx = int((wx - cam_x) * zoom)
            cy = int((wy - cam_y) * zoom)
            # Tire
            pygame.draw.circle(screen, BLACK, (cx, cy), int(self.wheel_radius * zoom), max(1, int(2*zoom)))
            # Rim
            pygame.draw.circle(screen, GRAY, (cx, cy), int(self.wheel_radius * zoom * 0.6))
            # Hub
            pygame.draw.circle(screen, BLACK, (cx, cy), int(self.wheel_radius * zoom * 0.2))
        
        # Frame and body
        cx = int((self.x - cam_x) * zoom)
        cy = int((self.y - cam_y) * zoom)
        
        # Rear to center
        pygame.draw.line(screen, BLUE,
                        (int((rear_wheel_x - cam_x) * zoom), int((rear_wheel_y - cam_y) * zoom)),
                        (cx, cy - int(5*zoom)),
                        max(1, int(4*zoom)))
        # Center to front
        pygame.draw.line(screen, BLUE,
                        (cx, cy - int(5*zoom)),
                        (int((front_wheel_x - cam_x) * zoom), int((front_wheel_y - cam_y) * zoom)),
                        max(1, int(4*zoom)))
        
        # Seat
        pygame.draw.rect(screen, GREEN,
                        (cx - int(10*zoom), cy - int(8*zoom), int(20*zoom), int(6*zoom)))
        
        # Handlebars / front post
        pygame.draw.line(screen, BLACK,
                        (cx, cy - int(5*zoom)),
                        (cx, cy - int(25*zoom)),
                        max(1, int(3*zoom)))
        # Handlebar cross
        pygame.draw.line(screen, BLACK,
                        (cx - int(8*zoom), cy - int(25*zoom)),
                        (cx + int(8*zoom), cy - int(25*zoom)),
                        max(1, int(3*zoom)))

# Create game objects
terrain = Terrain()
start_x = 50
start_y = terrain.get_height_at(start_x) - 20
vehicle = Vehicle(start_x, start_y)
vehicle.vy = 0
vehicle.vx = 0
vehicle.angle = 0
vehicle.angular_velocity = 0
rider = Rider(vehicle.x + 15, vehicle.y - 15)

# Control states
lean_state = 0  # -1 for backward, 1 for forward, 0 for neutral

# Touchscreen buttons (fully within 480x320)
button_width = 100
button_height = 60
accelerate_button = pygame.Rect(WIDTH - button_width - 10, HEIGHT - button_height - 10, button_width, button_height)
lean_left_button = pygame.Rect(10, HEIGHT - button_height - 10, button_width, button_height)
lean_right_button = pygame.Rect(10 + button_width + 10, HEIGHT - button_height - 10, button_width, button_height)

# Game loop
clock = pygame.time.Clock()
running = True

async def main():
    global running, cam_x, cam_y, vehicle, rider, lean_state
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.KEYDOWN:
                # Only one control at a time; single-key mapping
                if event.key == pygame.K_UP:
                    vehicle.accelerate()
                elif event.key == pygame.K_LEFT:
                    vehicle.lean_backward()
                    lean_state = -1
                elif event.key == pygame.K_RIGHT:
                    vehicle.lean_forward()
                    lean_state = 1
                elif event.key == pygame.K_SPACE:
                    # Jump: detach rider with upward velocity
                    if rider.on_vehicle:
                        rider.on_vehicle = False
                        rider.vy = -12
                        rider.vx = vehicle.vx * 0.8
                        rider.y = vehicle.y - 20

            elif event.type == pygame.KEYUP:
                if event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                    lean_state = 0

            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()

                # Touchscreen button checks
                if accelerate_button.collidepoint(mouse_pos):
                    vehicle.accelerate()

                elif lean_left_button.collidepoint(mouse_pos):
                    vehicle.lean_backward()
                    lean_state = -1

                elif lean_right_button.collidepoint(mouse_pos):
                    vehicle.lean_forward()
                    lean_state = 1

            elif event.type == pygame.MOUSEBUTTONUP:
                lean_state = 0

        # Update camera to follow bike closely
        cam_x = vehicle.x - WIDTH / (2 * zoom)
        cam_y = vehicle.y - HEIGHT / (2 * zoom)

        # Update game objects
        vehicle.update()
        rider.update(vehicle)

        # Check if rider fell off (simplified - if vehicle tilts too much)
        if abs(vehicle.angle) > math.pi/3 and rider.on_vehicle:
            rider.on_vehicle = False
            rider.vx = vehicle.vx
            rider.vy = vehicle.vy

        # Reset if rider falls off for too long
        if not rider.on_vehicle and rider.fall_timer > 180:  # 3 seconds at 60 FPS
            vehicle = Vehicle(50, terrain.get_height_at(50) - 20)
            vehicle.vy = 0
            vehicle.vx = 0
            vehicle.angle = 0
            vehicle.angular_velocity = 0
            rider = Rider(vehicle.x + 15, vehicle.y - 15)
            lean_state = 0

        # Rendering
        screen.fill(WHITE)

        # Draw terrain
        terrain.draw(screen)

        # Draw vehicle and rider (with attachment visuals)
        vehicle.draw(screen)
        rider.draw(screen, vehicle)

        # Draw touchscreen controls (fully inside screen)
        # Accelerate button
        pygame.draw.rect(screen, GREEN, accelerate_button, 0)
        pygame.draw.rect(screen, BLACK, accelerate_button, 3)
        accel_text = pygame.font.SysFont(None, 20).render("DRIVE", True, WHITE)
        screen.blit(accel_text, (accelerate_button.centerx - 30, accelerate_button.centery - 10))

        # Lean buttons
        pygame.draw.rect(screen, BLUE if lean_state == -1 else GRAY, lean_left_button, 0)
        pygame.draw.rect(screen, BLACK, lean_left_button, 3)
        left_text = pygame.font.SysFont(None, 20).render("LEAN L", True, WHITE)
        screen.blit(left_text, (lean_left_button.centerx - 35, lean_left_button.centery - 10))

        pygame.draw.rect(screen, BLUE if lean_state == 1 else GRAY, lean_right_button, 0)
        pygame.draw.rect(screen, BLACK, lean_right_button, 3)
        right_text = pygame.font.SysFont(None, 20).render("LEAN R", True, WHITE)
        screen.blit(right_text, (lean_right_button.centerx - 35, lean_right_button.centery - 10))

        # Draw instructions
        instr_text = pygame.font.SysFont(None, 18).render("UP: Drive | LEFT/RIGHT: Lean | SPACE: Jump | Touch buttons below", True, BLACK)
        screen.blit(instr_text, (10, 10))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)
    pygame.quit()

if __name__ == '__main__':
    asyncio.run(main())
